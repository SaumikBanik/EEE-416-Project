"""SmartGlove Python inference for the locked primary F1-F6 feature sets.
Use the package versions in inference_requirements.txt.
The returned prediction is a gesture ID; metadata contains the gesture names.
Calibration inputs must come from the current user's session, before prediction.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

WIN = 50
SAMPLE_PERIOD_MS = 40
ACC_LSB_PER_G = 8192.0
GYRO_LSB_PER_DPS = 16.4
FLEX = ['flex_thumb', 'flex_index', 'flex_middle', 'flex_ring', 'flex_little']
ACC = ['ax', 'ay', 'az']
GYRO = ['gx', 'gy', 'gz']
QUAT = ['qw', 'qx', 'qy', 'qz']
RAW_SENSOR_COLS = FLEX + ACC + GYRO + QUAT

FEATURE_SETS = {
    'F1_RAW_FLEX': [f'{f}_median' for f in FLEX],
    'F2_NEUTRAL_FLEX': [f'{f}_centered_median' for f in FLEX],
    'F3_RAW_FLEX_GRAVITY': [f'{f}_median' for f in FLEX] + ['gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z'],
    'F4_NEUTRAL_FLEX_GRAVITY': [f'{f}_centered_median' for f in FLEX] + ['gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z'],
    'F5_NEUTRAL_FLEX_STATIC_IMU': [f'{f}_centered_median' for f in FLEX]
        + ['gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z']
        + ['acc_mag_median_g', 'acc_mag_sd_g', 'gyro_mag_median_dps', 'gyro_mag_p95_dps'],
    'F6_NEUTRAL_FLEX_IQR': [f'{f}_centered_median' for f in FLEX] + [f'{f}_iqr' for f in FLEX],
}

def calibration_from_recordings(neutral_samples, gyro_bias_dps=None):
    """Construct a session calibration dictionary.

    For exact parity with training, pass the firmware/session gyro bias in deg/s
    when available. If omitted, the mean exported neutral gyro is used.
    """
    required = FLEX + ACC + GYRO
    if len(neutral_samples) < 2 or not np.isfinite(neutral_samples[required].to_numpy(float)).all():
        raise ValueError('Neutral calibration must contain finite flex/IMU samples.')
    result = {}
    for finger in FLEX:
        result[f'{finger}_neutral'] = float(neutral_samples[finger].mean())

    acc = neutral_samples[ACC].to_numpy(float) / ACC_LSB_PER_G
    acc_mean = acc.mean(axis=0)
    result['neutral_accel_x_g'] = float(acc_mean[0])
    result['neutral_accel_y_g'] = float(acc_mean[1])
    result['neutral_accel_z_g'] = float(acc_mean[2])

    if gyro_bias_dps is None:
        bias = (neutral_samples[GYRO].to_numpy(float) / GYRO_LSB_PER_DPS).mean(axis=0)
    else:
        bias = np.asarray(gyro_bias_dps, dtype=float)
        if bias.shape != (3,):
            raise ValueError('gyro_bias_dps must contain exactly three values.')
    if not np.isfinite(bias).all():
        raise ValueError('Non-finite gyro bias.')
    result['gyro_bias_x_dps'] = float(bias[0])
    result['gyro_bias_y_dps'] = float(bias[1])
    result['gyro_bias_z_dps'] = float(bias[2])
    return result

def extract_feature_pool(trial, calibration=None):
    if len(trial) != WIN:
        raise ValueError(f'Expected {WIN} samples, got {len(trial)}.')
    if not np.isfinite(trial[RAW_SENSOR_COLS].to_numpy(float)).all():
        raise ValueError('Non-finite sensor input to feature extraction.')
    if 'timestamp_ms' in trial.columns:
        timestamps = trial['timestamp_ms'].to_numpy(float)
        if not np.isfinite(timestamps).all() or not np.all(np.diff(timestamps) == SAMPLE_PERIOD_MS):
            raise ValueError('Trial timestamps must have 40 ms spacing.')

    out = {}
    flex = trial[FLEX].to_numpy(float)
    flex_median = np.median(flex, axis=0)
    q25 = np.percentile(flex, 25, axis=0, method='linear')
    q75 = np.percentile(flex, 75, axis=0, method='linear')
    for i, finger in enumerate(FLEX):
        out[f'{finger}_median'] = float(flex_median[i])
        out[f'{finger}_iqr'] = float(q75[i] - q25[i])

    if calibration is None:
        return out

    neutral_flex = np.array([float(calibration[f'{f}_neutral']) for f in FLEX])
    centered = flex_median - neutral_flex
    for i, finger in enumerate(FLEX):
        out[f'{finger}_centered_median'] = float(centered[i])

    acc = trial[ACC].to_numpy(float) / ACC_LSB_PER_G
    a_med = np.median(acc, axis=0)
    a_norm = float(np.linalg.norm(a_med))
    if a_norm <= 0:
        raise ValueError('Trial median acceleration vector has zero norm.')
    u = a_med / a_norm

    u0 = np.array([float(calibration['neutral_accel_x_g']),
                   float(calibration['neutral_accel_y_g']),
                   float(calibration['neutral_accel_z_g'])])
    u0_norm = float(np.linalg.norm(u0))
    if u0_norm <= 0:
        raise ValueError('Neutral acceleration vector has zero norm.')
    u_rel = u - (u0 / u0_norm)
    for name, value in zip(['gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z'], u_rel):
        out[name] = float(value)

    acc_mag = np.linalg.norm(acc, axis=1)
    out['acc_mag_median_g'] = float(np.median(acc_mag))
    out['acc_mag_sd_g'] = float(acc_mag.std(ddof=1))

    gyro = trial[GYRO].to_numpy(float) / GYRO_LSB_PER_DPS
    bias = np.array([float(calibration['gyro_bias_x_dps']),
                     float(calibration['gyro_bias_y_dps']),
                     float(calibration['gyro_bias_z_dps'])])
    gyro_mag = np.linalg.norm(gyro - bias, axis=1)
    out['gyro_mag_median_dps'] = float(np.median(gyro_mag))
    out['gyro_mag_p95_dps'] = float(np.percentile(gyro_mag, 95, method='linear'))

    if not np.isfinite(list(out.values())).all():
        raise ValueError('Feature extraction produced a non-finite value.')
    return out

def extract_features_for_set(trial, mode, calibration=None):
    if mode not in FEATURE_SETS:
        raise ValueError(f'Unknown feature set: {mode}')
    if mode != 'F1_RAW_FLEX' and calibration is None:
        raise ValueError(f'{mode} requires the current-session neutral calibration.')
    pool = extract_feature_pool(trial, calibration)
    cols = FEATURE_SETS[mode]
    missing = [c for c in cols if c not in pool]
    if missing:
        raise ValueError(f'Missing required features for {mode}: {missing}')
    return {c: pool[c] for c in cols}

def predict_trial(samples, bundle, calibration=None):
    """Predict one gesture from one completed 50-sample trial."""
    if isinstance(bundle, (str, Path)):
        bundle = joblib.load(bundle)
    metadata = bundle['metadata']
    expected = {'window_samples': WIN, 'sample_period_ms': SAMPLE_PERIOD_MS,
                'acc_lsb_per_g': ACC_LSB_PER_G, 'gyro_lsb_per_dps': GYRO_LSB_PER_DPS}
    for key, value in expected.items():
        if metadata[key] != value:
            raise ValueError(f'Inference constants do not match model metadata: {key}.')
    mode = metadata['selected_mode']
    features = extract_features_for_set(samples, mode, calibration)
    if list(features) != metadata['feature_columns']:
        raise ValueError('Feature schema differs from the trained model.')
    X = pd.DataFrame([features], columns=metadata['feature_columns'])
    return str(bundle['pipeline'].predict(X)[0])

WIN = 50
SAMPLE_PERIOD_MS = 40
ACC_LSB_PER_G = 8192.0
GYRO_LSB_PER_DPS = 16.4
FLEX = ['flex_thumb', 'flex_index', 'flex_middle', 'flex_ring', 'flex_little']
ACC = ['ax', 'ay', 'az']
GYRO = ['gx', 'gy', 'gz']
QUAT = ['qw', 'qx', 'qy', 'qz']
RAW_SENSOR_COLS = ['flex_thumb', 'flex_index', 'flex_middle', 'flex_ring', 'flex_little', 'ax', 'ay', 'az', 'gx', 'gy', 'gz', 'qw', 'qx', 'qy', 'qz']
FEATURE_SETS = {'F1_RAW_FLEX': ['flex_thumb_median', 'flex_index_median', 'flex_middle_median', 'flex_ring_median', 'flex_little_median'], 'F2_NEUTRAL_FLEX': ['flex_thumb_centered_median', 'flex_index_centered_median', 'flex_middle_centered_median', 'flex_ring_centered_median', 'flex_little_centered_median'], 'F3_RAW_FLEX_GRAVITY': ['flex_thumb_median', 'flex_index_median', 'flex_middle_median', 'flex_ring_median', 'flex_little_median', 'gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z'], 'F4_NEUTRAL_FLEX_GRAVITY': ['flex_thumb_centered_median', 'flex_index_centered_median', 'flex_middle_centered_median', 'flex_ring_centered_median', 'flex_little_centered_median', 'gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z'], 'F5_NEUTRAL_FLEX_STATIC_IMU': ['flex_thumb_centered_median', 'flex_index_centered_median', 'flex_middle_centered_median', 'flex_ring_centered_median', 'flex_little_centered_median', 'gravity_rel_x', 'gravity_rel_y', 'gravity_rel_z', 'acc_mag_median_g', 'acc_mag_sd_g', 'gyro_mag_median_dps', 'gyro_mag_p95_dps'], 'F6_NEUTRAL_FLEX_IQR': ['flex_thumb_centered_median', 'flex_index_centered_median', 'flex_middle_centered_median', 'flex_ring_centered_median', 'flex_little_centered_median', 'flex_thumb_iqr', 'flex_index_iqr', 'flex_middle_iqr', 'flex_ring_iqr', 'flex_little_iqr']}
