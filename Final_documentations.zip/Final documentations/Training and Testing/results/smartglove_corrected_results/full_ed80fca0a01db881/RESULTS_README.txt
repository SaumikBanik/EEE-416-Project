SmartGlove corrected classification — FULL run
Run ID: ed80fca0a01db881dcb96e19a8bb982a0e9424c57558e78a16012c5ae1635e89
Dataset SHA-256: 4217ffd727eb260a0867eb547b16111ddecf40d4c8c974bdab890755b6a8649b

primary_outer_summary.csv: primary generalization estimate of the full selection procedure.
outer_classifier_summary.csv: each classifier tuned separately inside the outer development set.
outer_feature_set_classifier_summary.csv: fixed F1-F6 feature-set/classifier comparisons.
inner_feature_set_performance.csv: INNER-CV descriptive feature-set results, not independent test accuracies.
fit_warnings.csv: review any convergence/numerical warnings.
calibration_reference_diagnostics.csv: measured references; span is diagnostic only in the primary experiment.
final_model_bundle.joblib: all-participant refit, if enabled; no new independent test score.
smartglove_inference.py: Python inference from 50 sensor rows with the required session calibration.
inference_requirements.txt: package versions used to create the model.

SD is between-participant variation, not a confidence interval.
F2-F6 require the current-session neutral calibration; F1 uses raw flex medians.
Do not choose a new model from outer scores and reuse its best score as an untouched evaluation.
SMOKE outputs, when present, are software checks and are not the full experiment.
Checkpoints can resume matching runs only while these files remain accessible.
