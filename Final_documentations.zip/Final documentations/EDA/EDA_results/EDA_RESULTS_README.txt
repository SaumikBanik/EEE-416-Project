SMARTGLOVE EDA OUTPUT GUIDE

Start with SCIENTIFIC_INTERPRETATION.md, final_quality_summary.csv and priority_manual_review.csv.
PASS is scoped to the specific check; REVIEW does not mean delete. Never treat sample rows as independent trials.

file_manifest.csv: All source paths, row counts, byte sizes and SHA256 digests; raw sources are not modified.
schema_inventory.csv: Exact observed schema for every CSV, including support files.
participant_structure.csv: Compact structural inventory by participant.
trial_integrity.csv: Objective row, timestamp, missing and duplicate checks for each trial.
structure_audit.csv: Formal structural and provenance checks; FAIL is reserved for hard inconsistencies.
rejected_file_audit.csv: Rejected-file event identity and exact accepted-payload contamination check.
accepted_trial_index.csv: One row per accepted participant/gesture/trial; complete logs and verified session/reference mapping.
attempt_summary.csv: Attempt counts, including retries; these are not additional independent accepted trials.
session_summary.csv: All named sessions, including zero-accepted-trial sessions; events with session - remain in event_inventory.csv.
event_inventory.csv: Full session-event evidence; details preserve recorded firmware criteria and restart explanations.
participant_event_summary.csv: Participant-level counts include unnamed-session calibration rejections and link events.
attempt_reasons.csv: Unsuccessful attempts by result and operator/connection reason.
irregularities.csv: Documented anomalies classified separately from signal defects.
trial_balance.csv: Accepted trial counts, never sample rows.
flex_trial_statistics.csv: All nine requested flex statistics plus rails, distinct values and largest adjacent step.
flex_sensor_summary.csv: Sample-level physical range and trial-level constant-channel counts.
calibration_summary_eda.csv: Session/finger neutral and fist statistics, signed spans, summary cross-checks and stability metrics.
calibration_review.csv: Reference direction and small-span warnings; a difference is not proof of sensor polarity reversal.
calibration_timing.csv: Whether each accepted trial follows its mapped calibration; fist event timing is listed separately below.
fist_reference_timing.csv: Prospective availability of the session fist reference.
calibration_session_changes.csv: Baseline changes across recalibration sessions; not assumed to be electronic drift.
quaternion_norm_summary.csv: Raw quaternion validity before any normalization.
gyro_peak_definition_review.csv: Raw and bias-corrected sampled peaks versus firmware logs; mismatches do not prove incorrect units without firmware timing/definition evidence.
motion_log_comparison.csv: Recomputed motion and logged QC; angular definitions and gyro bias handling may differ.
checkpoint_drift.csv: Same-session angular deviation for checkpoints and final holds; includes log cross-check and session relevance.
checkpoint_flex_drift.csv: Neutral flex change in ADC and signed fist-span units; final holds kept distinct.
gesture_position_balance.csv: Observed accepted gesture × position counts; verifies rather than assumes balance.
temporal_associations.csv: Descriptive Spearman correlations after within-participant/session/gesture demeaning; no causality or independent-trial inference.
trial_level_features_raw.csv: 500 trial-level records: identity, provenance, all raw summaries and descriptive QC features; no classifier trained.
variation_decomposition_raw.csv: Balanced descriptive sums of squares; no independent-sample F tests.
gesture_separation_exploratory.csv: All pairwise centroid-to-dispersion ratios in standardized raw flex space; no accuracy claims.
strong_correlations.csv: Candidate redundancy using exploratory |Spearman rho| >= .90.
within_participant_correlations.csv: Demeaned descriptive correlation matrix to compare with pooled correlations.
pca_coordinates.csv: Descriptive full-dataset standardized PCA; refit preprocessing inside future training folds.
pca_variance.csv: Variance explained, not class prediction performance.
silhouette_exploratory.csv: Exploratory full-standardized-space label compactness; never accuracy.
trial_features_exploratory_normalized.csv: Separate retrospective calibration comparisons; signed spans preserved, invalid denominators left NaN.
normalization_variation_comparison.csv: Same-cohort descriptive variance fractions; omitted if eligibility destroys complete balance.
normalization_silhouette_comparison.csv: Same-cohort full-space silhouette; no claim of predictive improvement.
qc_flags_long.csv: One row per triggered metric and comparison distribution, allowing multiple flags per trial.
qc_flagged_trials.csv: One row per suspicious accepted trial; aligned JSON arrays preserve every metric/value/threshold/reason/type/severity.
qc_thresholds.csv: All empirical 3-IQR fences and group sizes; exploratory rather than acquisition acceptance criteria.
priority_manual_review.csv: Six largest flex-range traces for manual inspection; review candidates, not exclusions.
rejected_signal_statistics.csv: Rejected-only descriptive signals; explicitly excluded from T and PCA.
attempt_detail_counts.csv: Accepted/discarded/failed counts by participant, gesture and reason.
final_quality_summary.csv: Evidence/action dashboard. PASS is scoped to the stated evidence; REVIEW is not FAIL.
SCIENTIFIC_INTERPRETATION.md: Sixteen evidence-qualified answers and justified verdict from the executed data.

plots/: question-driven figures.
extracted_input/: unchanged source bytes when a ZIP was supplied; not newly cleaned data.

Units: ADC raw counts; gyro deg/s from /16.4; acceleration g from /8192; angles degrees. Configuration is supplied by the researcher, not established by the CSV.

All 3-IQR, near-rail and calibration denominator rules are exploratory review heuristics. No automated removal; raw features remain separate from calibration comparisons.
